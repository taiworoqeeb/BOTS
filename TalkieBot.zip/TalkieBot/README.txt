Hello, This contains the source code of the bot. if you want to run it locally on your pc via Vscode or other ide you can with this.

NOTE: A bot can only the authorize into a server if you are the admin of the server or given permission to manage the server,
the bot created in a way that only the admin can send messages to DMs to avoid anyone misusing it but if need be that you don't want that i can remove it,
for the bot to work in sending DMs to the users the bot and the users must be on the same server.

> Just open the file in any IDE of your choice (Recommended VSCODE) and make sure install nodejs and updated npm on your pc
> Then right click on the folder in vscode the select to open in terminal
> Then type "npm i"
> then "npm start"
> then you have locally hosted it.

Technically i have hosted it on heroku so don't need that above anyways. Will show you the images on heroku and discord.
Now can we move on to the next milestone (Testing and teaching how to use it) please, we can have video call to explain how it works then after i will forward a readme file for the use of the bot.