Hello, 
This file contains the source code of the bot. if you want to run it locally on your pc via Vscode or other IDEs.

NOTE: A bot can only be authorized into a server if you are the admin/owner of the server or given permission to manage the server.

The bot is created in a way that only the admin can send messages to DMs to avoid anyone misusing it but if need be that you don't want that I can remove it.

For the bot to work in sending DMs to the users the bot and the users must be on the same server.

> Just open the file in any IDE of your choice (Recommended Vscode) and make sure to install NodeJs and update "npm" on your PC

> Then right-click on the folder in Vscode the select to open the integrated terminal
> Then type "npm i"
> then "npm start"
> then you have locally hosted it.

I have hosted it on Heroku already, so you don't need all that above anyways. Will show you the images on Heroku and discord.

Now we can move on to the next milestone (Testing and teaching how to use it), we can have a video call to explain how it works and test it, then I will forward a readme file for the use of the bot.